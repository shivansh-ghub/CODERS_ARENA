# Codeers Arena — Coding Practice Platform MVP

A polished, responsive LeetCode-inspired frontend prototype built with HTML, CSS, and vanilla JavaScript.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. No install or build step is required.

## Included
- Dashboard with activity, weekly goal, streak, and progress cards
- Searchable/filterable problem library with difficulty/topic/status
- Interactive coding workspace with starter templates
- Browser-based JavaScript sample test runner for supported problems
- Progress view, saved-problem UI, responsive layout, and toast feedback

## Important MVP limitations
- Dashboard numbers and profile metrics are demo data.
- Progress is in-memory only and resets on refresh.
- JavaScript tests run locally in the browser; Python/C++/Java are UI previews only.
- This is not yet a production coding judge. A real public platform needs a backend API, database/authentication, persistent submissions, and isolated execution (e.g. Judge0 or a securely sandboxed worker). Never execute untrusted code on a server without isolation, resource limits, and timeouts.

## Resume description (only after you understand and customize it)
**Codeers Arena — Online Coding Practice Platform (Frontend MVP)**  
Built a responsive coding-practice dashboard with searchable problem sets, topic/difficulty filters, an interactive editor, and browser-based JavaScript sample testing. Designed modular UI views for progress analytics, streak tracking, and saved problems.  
**Tech:** HTML5, CSS3, JavaScript (ES6), responsive UI, DOM APIs.

To make it stronger for a resume, implement authentication, PostgreSQL-backed users/problems/submissions, a secure judge service, and automated tests before describing those features as complete.
